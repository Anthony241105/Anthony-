from ___Value_Row___ import Value_Row
def Value_column(self,i):
        list_column=[]
        for e in range(len(self.matriz)):
           list_column.append(Value_Row(self,e)[i])
        return list_column