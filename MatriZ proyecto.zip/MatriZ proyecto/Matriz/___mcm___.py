def mcm(Num_1,Num_2):
      if Num_1*Num_2==0:
          return 0
      else:
        for Numero in range(1,abs(Num_1*Num_2)+1):
           if Numero%Num_1==0 and Numero%Num_2==0 and Numero!=0:
             return Numero
             break
    
    

