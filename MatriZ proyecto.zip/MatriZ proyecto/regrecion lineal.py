import numpy as np 
from Matriz import ___main___
def Intercept_regretion(self,array_y):
    X=np.array(self.matri)
    Y=np.array(array_y)
    x_b=np.c_[np.ones((X.shape[0],1)),X]
    beta = np.linalg.inv(x_b.T @ x_b) @ x_b.T @ Y
    return beta 

