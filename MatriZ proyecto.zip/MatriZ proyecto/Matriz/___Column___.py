from ___Value_Row___ import Value_Row
def Column(self,i,Matriz):
    list_column=Matriz
    for e in range(len(self.matriz)):
        h=Value_Row(self,e)
        list_column.matriz.append([h[i]])
    return list_column 