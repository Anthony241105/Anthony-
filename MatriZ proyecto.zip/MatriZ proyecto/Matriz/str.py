def str_(self):
        string=""
        for i in self.matriz:
            string=string+"["
            for e in i:
               string=string+str(e)+" "
            string=string[0:-1]+"]"+"\n"
        string=string[0:-1]   
        return string