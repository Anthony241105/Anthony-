import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from Matriz_loading import Matriz_loading
from Load_Data import Load_Data
from new_ubicacion import new_ubicacion
from Matriz import ___main___
from Random_data import Random_data
from String_list import String_list
def boton_Matriz_Solución():
           st.subheader("Necesita insertar una solución en forma de lista")
           V2=st.text_input("Solución")
           V3=String_list(V2)
           V4=___main___.Matriz.Matriz_solution(V1.matriz,V3)
           V5=___main___.V4.__Solution__()
           st.text(V5)
