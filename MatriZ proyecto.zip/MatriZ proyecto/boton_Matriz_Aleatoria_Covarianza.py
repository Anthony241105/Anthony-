import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
from Matriz import ___main___

#from String_list import String_list
#from boton_Matriz_Solución import boton_Matriz_Solución
def boton_Matriz_Aleatoria_Covarianza():
            st.subheader("Los valores de la diagonal son los valores de las varianza y los valores exteriores las covarinazas")
            V2=___main___.Matriz_covarianza(V1)
            st.text(V2)

