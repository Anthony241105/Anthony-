import random
def Random_data(i,j):
    matriz=[]
    for m in range(i):
        fila=[]
        for y in range(j):
            a=random.randint(1,50)
            fila.append(a)
        matriz.append(fila)
    return matriz


