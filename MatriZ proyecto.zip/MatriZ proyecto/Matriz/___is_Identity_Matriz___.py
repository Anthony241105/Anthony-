def is_Identity_Matriz(self):
    for i in range(len(self.matriz)):
        row=self.matriz[i]
        for j in range(len(row)):
            if i == j and row[j]!=1:
                return False
            elif i!=j and row[j]!=0:
                return False
    return True