from Load_Data import Load_Data
from Data_columna import Data_columna
from Data_fila import Data_fila
def Matriz_loading(Data: str=None,directory:str=None):
    a=Load_Data(Data,directory)
    a=Data_fila(a)
    print(a)
    Matriz=Data_columna(a)
    return Matriz

