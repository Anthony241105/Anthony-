def String_list(a):
    l=[]
    num=""
    for i in range(len(a)):
        if a[i]==" ":
            num=int(num)
            l.append(num)
            num=""
        elif i==len(a)-1:
            num=num+a[i]
            num=int(num)
            l.append(num)
        else:
            num=num+a[i]
    return l

