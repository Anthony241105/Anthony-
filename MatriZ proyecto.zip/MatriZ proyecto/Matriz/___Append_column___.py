from ___Value_column___ import Value_column
def Append_column(self,j):
    h=self.matriz
    if len(j)==len(h[0]):
        for i in range(len(h)):
            h[i].append(j[i])
        return h
    else:
        return None
