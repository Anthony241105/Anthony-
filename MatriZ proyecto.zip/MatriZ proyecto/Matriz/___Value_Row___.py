def Value_Row(self,i):
    return self.matriz[i]