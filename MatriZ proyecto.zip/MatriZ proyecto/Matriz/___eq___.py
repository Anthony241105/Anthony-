def ___eq___(self,self_1):
       if self.matriz==self_1.matriz:
            return True
       else:
            return False   