import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from Matriz_loading import Matriz_loading
from Load_Data import Load_Data
from new_ubicacion import new_ubicacion
from Matriz import ___main___
from Random_data import Random_data
from String_list import String_list
#from boton_Matriz_Solución import boton_Matriz_Solución
#from boton_Matriz_Aleatoria_Covarianza import boton_Matriz_Aleatoria_Covarianza

placeholder= st.empty()
Image.open("C:/Users/ANAISY/datos1-1.jpg")
st.image("C:/Users/ANAISY/datos1-1.jpg",use_container_width=True)
st.title("Bienvenido Stadists")
st.subheader("Rellene este pequeño formulario para poder acceder a Stadists")
#Ubicacion=st.text_input("Diga Ubicación del Archivo")
#archivo=st.text_input("Diga Nombre del Archivo")
col1, col2=st.columns(2)
with col1:
    Ubicacion=st.text_input("Diga Ubicación del Archivo")
    t=st.selectbox("Elija la accion a realizar",["Regrecion lineal","Matriz de covarianza","Regrecion Multivariada","Analisis de Graficos"])
    #st.radio("Que desea hacer",["Varianza","Moda","Media_aricmetica"])
with col2:
    archivo=st.text_input("Diga Nombre del Archivo")
    #c=st.radio("En que Formato se encuentran los datos",([".txt",".doc",'.zip']))
    b=st.selectbox("Elija que necesita",["Gráfico","Valoración de datos","Muestreo de Variable","Visualización de datos Aleatorios"])
    #archivo=archivo+c
w=[]
if len(Ubicacion)>=2 and len(archivo)>=2:
    Ubicacion=new_ubicacion(Ubicacion)
    #d=Load_Data(archivo,Ubicacion)
    w=Matriz_loading(archivo,Ubicacion)
    d=___main___.Matriz_(w)
    

#d=Matriz_loading("Data.txt","C:/Users/ANAISY/proyecto")
#print(d)
if b=="Visualización de datos Aleatorios":
    st.title("Visualización de datos Aleatorios")
    st.header("Esto es un versión beta en la que puede realizar pruebas del programa a partir de la biblioteca Random")
    st.subheader("Escriba la cantidad de filas y columnas")
    filas=st.text_input("Numero de filas")
    columnas=st.text_input("Numero de Columnas")
    V6=st.text_input("Solución")
    if st.button("Iniciar creación"):
        TY=Random_data(int(filas),int(columnas))
        V1=___main___.Matriz_(TY)
        st.subheader("Matriz Aleatoria")
        st.text(V1)
        st.title("Gráfico")
    #V1=w
    #plt.plot([1,2,3],[2,3,4])
    #x = np.linspace(0,10,100)
    #y = np.sin(x)
        fig, ax =plt.subplots()
        ax.plot(TY)
        ax.set_title("Representación de la matriz aleatoria")
        ax.set_xlabel("Eje x")
        ax.set_ylabel("Eje y")
        st.pyplot(fig)
        st.subheader("Matriz Covarinaza")
        V2=___main___.Matriz_covarianza(V1)
        st.text(V2)
    
        st.subheader("Gaus")
        
        V9=___main___.Gaus(V1)
        st.text(V9)
        st.subheader("Determinante Matriz")
        V8=___main___.Determinant(V1.matriz)
        st.text(V8)
        
        st.subheader("Solución")
        
        V3=String_list(V6)
        V4=___main___.Matriz.Matriz_solution(V1.matriz,V3)
        V5=___main___.Matriz.Matriz_solution.__Solution__(V4)
        st.text(V5)

        #if st.button("Matriz Aleatoria Covarianza"):
           # st.subheader("Los valores de la diagonal son los valores de las varianza y los valores exteriores las covarinazas")
           # V2=___main___.Matriz_covarianza(V1)
            #st.text(V2)
        #elif st.button("Matriz Solución"):
            # st.subheader("Necesita insertar una solución en forma de lista")
            # V2=st.text_input("Solución")
            # V3=String_list(V2)
             #V4=___main___.Matriz.Matriz_solution(V1.matriz,V3)
            # V5=___main___.V4.__Solution__()
            # st.text(V5)

elif b=="Gráfico":
    st.title("Gráfico")
    #V1=w
    #plt.plot([1,2,3],[2,3,4])
    #x = np.linspace(0,10,100)
    #y = np.sin(x)
    fig, ax =plt.subplots()
    ax.plot(w)
    ax.set_title("Representación de la matriz")
    ax.set_xlabel("Eje x")
    ax.set_ylabel("Eje y")
    st.pyplot(fig)
    ax.boxplot(w,patch_artist=True)
    st.pyplot(fig)


elif b=="Valoración de datos":
    st.title("Valoración de datos")
    st.header("Esta es la matriz de datos con la que trabajaremos")
    st.text(str(d))
    zt=st.selectbox("Elija que necesita",["Matriz Covarianza","Matriz Markov","Matriz de diseño en Regreción","Matriz de Transision en cadenas","Matriz de Confusión","Matriz de incidencia y adyacencia","Matriz en analisis de varinza"])
    if zt=="Matriz Covarianza":
       st.header("Matriz Covarianza")
       st.subheader("Los valores de la diagonal son los valores de las varianza y los valores exteriores las covarinazas")
       V2=___main___.Matriz_covarianza(d)
       st.text(V2)
    elif zt=="Matriz Markov":
       st.header("Matriz Markov")
       V3=d*d
       st.text(V3)
    elif  zt=="Matriz de diseño en Regreción":
       st.header("Matriz de diseño en Regreción")
       V4=d*d+d
       st.text(V4)
    elif  zt=="Matriz de Transision en cadenas":
       st.header("Matriz de Transision en cadenas")
       V5=d*(d+d*d)+d
       st.text(V5)
    elif  zt=="Matriz de Confusión":
       st.header("Matriz de Confusión")
       V6=d*d*d*d+d*d
       st.text(V6)
    elif  zt=="Matriz de incidencia y adyacencia":
       st.header("Matriz de incidencia y adyacencia")
       V7=(d*d*d)+d*d
       st.text(V7)
    elif  zt=="Matriz en analisis de varinza":
       st.button("Matriz en analisis de varinza")
       V8=(d*d*d+d*d+d)+d*d+d
       st.text(V8)




#st.write("Hola,esta es una prueba sencilla de streamlit")
#st.header("hola como estas")
#st.subheader("bien bien")
#st.markdown("claro claro")
#st.caption("asi somos")
#st.code(print("hola mundo"))
#st.latex(4+4)
#st.button("print")
#st.checkbox("ghost")
#st.radio("erty","option")
#st.selectbox("werty","option")
#st.multiselect("westy","option")
#st.slider("o")
#st.text_input("introduce")
#st.number_input("number")
#st.date_input("hello")
#st.time_input("t")
#st.text_area("a")
#st.file_uploader("r")
#st.color_picker('w')
#cd proyecto
#streamlit run app.py
