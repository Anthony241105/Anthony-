def is_Null_Matriz(self):
    for row in self.matriz:
        for element in row:
            if element != 0:
                return False
    return True