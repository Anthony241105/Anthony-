def Data_fila(self):
      listfile=[]
      fila=""
      self=str(self)
      for i in range(len(self)):
        if self[i]!="\n":
           fila=fila+self[i]
           print(fila)
        elif i==len(self)-1:
           listfile.append(fila)
           print(fila)
        else:
           listfile.append(fila)
           fila=""
      return listfile


