from ___mcm___ import mcm
def Gaus(matriz:list=[],Fila_indice:int=0,Columna_indice:int=0,Value:int=0):
    if Fila_indice<len(matriz)-1 and Columna_indice<len(matriz[Fila_indice])-1:
        if matriz[Fila_indice][Columna_indice]==0 and Value<=len(matriz):
            fila=matriz[Fila_indice]
            matriz.pop(Fila_indice)
            matriz.append(fila)
            return Gaus(matriz,Fila_indice,Columna_indice,Value+1)
        elif Value>len(matriz):
            return Gaus(matriz,Fila_indice,Columna_indice+1,0)
        else:
            for i in range(Fila_indice+1,len(matriz)):
               fila=[]
               for j in range(len(matriz[Fila_indice])):
                      if matriz[i][Columna_indice]==0:
                         fila=matriz[i]
                         break
                      else:
                          fila.append(int((matriz[Fila_indice][j]*mcm(matriz[Fila_indice][Columna_indice],matriz[i][Columna_indice])/matriz[Fila_indice][Columna_indice])-(matriz[i][j]*mcm(matriz[Fila_indice][Columna_indice],matriz[i][Columna_indice])/matriz[i][Columna_indice])))
               matriz[i]=fila
            return Gaus(matriz,Fila_indice+1,Columna_indice+1)
    else:
        return matriz
