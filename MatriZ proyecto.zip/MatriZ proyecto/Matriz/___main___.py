import math
#import ___Value_column___ #import Value_column
#from ___Value_Row___ import Value_Row
#from ___Row___ import Row
#from ___Column___ import Column
#from ___is_Column___ import is_Column
#from ___is_Square_Matriz___ import is_Square_Matriz
#from ___is_Null_Matriz___ import is_Null_Matriz
#from ___is_Identity_Matriz___ import is_Identity_Matriz
#from ___add___ import ___add___
#from ___mul___ import ___mul___
#from ___Determinant___ import Determinant
#from ___Gaus___ import Gaus
#from ___Append_column___ import Append_column
#from ___Solution___ import Solution 
class Matriz():
    def __init__(self,matriz):
          self.matriz=matriz
          
    def __str__(self):
        string=""
        for i in self.matriz:
            string=string+"["
            for e in i:
               string=string+str(e)+" "
            string=string[0:-1]+"]"+"\n"
        string=string[0:-1]   
        return string
        
    
    def __eq__(self):
       if self.matriz==self_1.matriz:
            return True
       else:
            return False   
        
    def __len__(self):
        return len(self.matriz)
    
    def __mul__(self,self_1):
        a=True
        if not __is_Matriz__(self_1) or not __is_Matriz__(self):
            a=False                                
        matriz=[]
        if type(self)==type(self_1) and a:
            if len(Value_Row(self,0))==len(Value_column(self_1,0)):
                for i in range(len(Value_column(self,0))):
                    list_mul=[]
                    for m in range(len(Value_Row(self_1,0))):
                        mul=0 
                        for j in range(len(Value_column(self_1,0))):
                             mul=mul+Value_Row(self,i)[j]*Value_column(self_1,m)[j]
                        list_mul.append(mul)
                    matriz.append(list_mul)
                return Matriz(matriz)
            
            else:
                return None
        elif type(self_1)==int:
            for i in range(len(self.matriz)):
                list_mul=[]
                for j in range(len(self.matriz[0])):
                    mul=self.matriz[i][j]*self_1
                    list_mul.append(mul)
                matriz.append(list_mul)
            return Matriz(matriz)
        elif type(self)==int:
            return ___mul___(self_1,self)
        else:
            return None
    
                                                                             
    def __list__(self):
        return self.matriz
    
    def __add__(self,self_1):
        Result=Matriz([])
        if __is_Square_Matriz__(self) and __is_Square_Matriz__(self_1) and len(self)==len(self_1):
            for i in range(len(self.matriz)):
                       row=[]
                       for j in range(len(self.matriz[0])):
                             add=self.matriz[i][j]+self_1.matriz[i][j]
                             row.append(add)
                       Result.matriz.append(row) 
        return Result
    class Matriz_solution():
        def __init__(self,matriz,value_result):
            self.matriz=matriz
            self.result=value_result
        def __Solution__(self):
            r=self
            mat=Matriz(self.matriz)
            if __is_Square_Matriz__(mat):
                app=Append_column(self,self.result)
                w=Gaus(app).matriz
                l=[]
                for x in range(len(self.matriz)):
                    l.append(None)
                y=Value_column(r,-1)
                if Determinant(self.matriz)!=0:
                    for i in range (len(w),0,-1):
                        for e in range (len(w),0,-1):
                            if w[i-1][e-1]!=0 and l[e-1]!=None:
                                y[i-1]=y[i-1]-l[e-1]*w[i-1][e-1]
                            elif w[i-1][e-1]!=0 and l[e-1]==None:
                                l[e-1]= float(y[i-1])/w[i-1][e-1]
                        #elif w[i-1][e-1]!=0 and l[e-1]!=None:
                            #self.result[i-1]=(self.result[i-1]-l[e-1]*w[i-1][e-1])
                    return l
                else:
                    return None
            else:
                return None
              
                           
def Matriz_covarianza(self):
    if __is_Square_Matriz__(self):
       list_traspuesta=[]
       list_value=[]
       list_centrados=[]
       for i in self.matriz:
           list_traspuesta.append([])
           media=float(math.fsum(i))/len(i)
           media=float.__round__(media,1)
           for e in i:
                V=media-e
                V=float.__round__(V,1)
                list_centrados.append(V)
           list_value.append(list_centrados)
           list_centrados=[]
       Matriz_value=Matriz(list_value)
       Matriz_traspuesta=Matriz(list_traspuesta)
       for j in range(len(Matriz_value.matriz)):
          s=Value_Row(Matriz_value,j)
          Matriz_traspuesta=Append_column(Matriz_traspuesta,s)
       return Matriz_traspuesta*Matriz_value
    else:
        return (None,"Matriz No Cuadrada")                            


def Matriz_(self):
    return Matriz(self)

        
def __is_Column__(self):
        Ma=Matriz([])
        if self.matriz == __Column__(self,0).matriz:
            return True
        else:
            return False
    
    
def __is_Matriz__(self):
    if type(self)==Matriz:
        return True
    else:
        return False
    
def __is_Null_Matriz__(self):
    for row in self.matriz:
        for element in row:
            if element != 0:
                return False
    return True
    
def __is_Square_Matriz__(self):
    if __is_Matriz__(self) and len(self.matriz)==len(self.matriz[0]):
        return True
    else:
        return False
    
def __is_Identity_Matriz__(self):
    for i in range(len(self.matriz)):
        row=self.matriz[i]
        for j in range(len(row)):
            if i == j and row[j]!=1:
                return False
            elif i!=j and row[j]!=0 :
                return False
    if __is_Square_Matriz__(self):
        return True
    
    
def __Row__(self,i):
    Row=Matriz([self.matriz[i]])
    return Row

def __Column__(self,i):
    list_column=Matriz([])
    for e in range(len(self.matriz)):
        h=Value_Row(self,e)
        list_column.matriz.append([h[i]])
    return list_column 
def Menor(Matriz:list=[],Fila_indice:int=0,Columna_indice:int=0):
    M=[]
    if len(Matriz)==len(Matriz[0]):
        for fila in Matriz:
            C=[]
            for i in fila: C.append(i)
            M.append(C)
        M.pop(Fila_indice)
        for i in range(len(M)): M[i].pop(Columna_indice)
        return M
    
def Determinant(self=[],Fila_indice=0,Columna_indice=0):
    Matriz=list(self)
    if len(Matriz)==len(Matriz[0])>Columna_indice:
       if len(Matriz)==1:
           return Matriz[0][0]
       else:
          return (Matriz[Fila_indice][Columna_indice]*Determinant(Menor(Matriz,Fila_indice,Columna_indice)))-Determinant(Matriz,Fila_indice,Columna_indice+1)
    elif Columna_indice>=len(Matriz[0]):
        return 0
    else:
        None
        #return Determinant(Matriz)


def Gaus(self:list=[],Fila_indice:int=0,Columna_indice:int=0,Value:int=0):
    matriz=self.matriz
    if Fila_indice<len(matriz)-1 and Columna_indice<len(matriz[Fila_indice])-1:
        if matriz[Fila_indice][Columna_indice]==0 and Value<=len(matriz):
            fila=matriz[Fila_indice]
            matriz.pop(Fila_indice)
            matriz.append(fila)
            return Gaus(Matriz(matriz),Fila_indice,Columna_indice,Value+1)
        elif Value>len(matriz):
            return Gaus(Matriz(matriz),Fila_indice,Columna_indice+1,0)
        else:
            for i in range(Fila_indice+1,len(matriz)):
               fila=[]
               for j in range(len(matriz[Fila_indice])):
                      if matriz[i][Columna_indice]==0:
                         fila=matriz[i]
                         break
                      else:
                          fila.append(int((matriz[Fila_indice][j]*mcm(matriz[Fila_indice][Columna_indice],matriz[i][Columna_indice])/matriz[Fila_indice][Columna_indice])-(matriz[i][j]*mcm(matriz[Fila_indice][Columna_indice],matriz[i][Columna_indice])/matriz[i][Columna_indice])))
               matriz[i]=fila
            return Gaus(Matriz(matriz),Fila_indice+1,Columna_indice+1)
    else:
        return Matriz(matriz)
    
#def __Solution__(self,result):
    #return 
def Append_column(self,j):
    h=self.matriz
    for i in range(len(h)):
        h[i].append(j[i])
    return Matriz(h)
    

def Value_column(self,i):
        list_column=[]
        for e in range(len(self.matriz)):
           a=Value_Row(self,e)
           list_column.append(a[i])
        return list_column
def Value_Row(self,i):
    return self.matriz[i]
def mcm(Num_1,Num_2):
      if Num_1*Num_2==0:
          return 0
      else:
        for Numero in range(1,abs(Num_1*Num_2)+1):
           if Numero%Num_1==0 and Numero%Num_2==0 and Numero!=0:
             return Numero
             
def Matriz_covarianza(self):
    if __is_Square_Matriz__(self):
       list_traspuesta=[]
       list_value=[]
       list_centrados=[]
       for i in self.matriz:
           list_traspuesta.append([])
           media=float(math.fsum(i))/len(i)
           media=float.__round__(media,1)
           
           for e in i:
                V=media-e
                V=float.__round__(V,1)
                list_centrados.append(V)
           list_value.append(list_centrados)
           list_centrados=[]
       Matriz_value=Matriz(list_value)
       Matriz_traspuesta=Matriz(list_traspuesta)
       for j in range(len(Matriz_value.matriz)):
          s=Value_Row(Matriz_value,j)
          Matriz_traspuesta=Append_column(Matriz_traspuesta,s)
       return Matriz_traspuesta*Matriz_value
    else:
        return (None,"Matriz No Cuadrada")



#a=Matriz([[1,2,3],[4,6,7],[7,3,5]])
#print(a.matriz)
#print(Matriz_covarianza(a))
#b=Matriz.Matriz_solution([[1,2,4],[2,6,6],[7,3,7]],[4,2,3])
#a=[[1,2,4],[2,6,6],[7,3,7]]
#print(a[1])
#b=b.__Solution__()
#print(b)
#a=[[1,2],[2,3]]
#b=(Gaus(a))
#print(b)
#print(b*a*8*a)

