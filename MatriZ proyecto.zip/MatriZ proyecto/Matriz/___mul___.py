from ___Value_column___ import Value_column
from ___Value_Row___ import Value_Row
def ___mul___(self,self_1,a):
    matriz=[]
    if type(self)==type(self_1) and a:
        if len(Value_Row(self,0))==len(Value_column(self_1,0)):
            for i in range(len(Value_column(self,0))):
                list_mul=[]
                for m in range(len(Value_Row(self_1,0))):
                    mul=0 
                    for j in range(len(Value_column(self_1,0))):
                         mul=mul+Value_Row(self,i)[j]*Value_column(self_1,m)[j]
                    list_mul.append(mul)
                matriz.append(list_mul)
            return matriz
            
        else:
            return None
    elif type(self_1)==int:
        for i in range(len(self.matriz)):
            list_mul=[]
            for j in range(len(self.matriz[0])):
                mul=self.matriz[i][j]*self_1
                list_mul.append(mul)
            matriz.append(list_mul)
        return matriz
    elif type(self)==int:
        return ___mul___(self_1,self)
    else:
        return None
        
    