from Matriz import ___main___, Mz_
def Mz(self):
    return Matriz_(self)