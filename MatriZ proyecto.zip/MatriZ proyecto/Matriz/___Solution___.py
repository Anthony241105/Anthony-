from ___Append_column___ import Append_column
from ___Gaus___ import Gaus
from ___Value_column___ import Value_column
from ___Determinant___ import Determinant
def Solution(self,w,r,app):
            l=[]
            for x in range(len(self.matriz)):
                l.append(None)
            
            w=Gaus(app)
            y=Value_column(r,-1)
            if Determinant(self.matriz)!=0:
                for i in range (len(w),0,-1):
                    for e in range (len(w),0,-1):
                        if w[i-1][e-1]!=0 and l[e-1]!=None:
                            y[i-1]=y[i-1]-l[e-1]*w[i-1][e-1]
                        elif w[i-1][e-1]!=0 and l[e-1]==None:
                            l[e-1]= float(y[i-1])/w[i-1][e-1]
                        #elif w[i-1][e-1]!=0 and l[e-1]!=None:
                            #self.result[i-1]=(self.result[i-1]-l[e-1]*w[i-1][e-1])
                return l
            else:
                return None