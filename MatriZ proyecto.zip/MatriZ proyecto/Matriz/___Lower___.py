def Menor(Matriz:list=[],Fila_indice:int=0,Columna_indice:int=0):
    M=[]
    if len(Matriz)==len(Matriz[0]):
        for fila in Matriz:
            C=[]
            for i in fila: C.append(i)
            M.append(C)
        M.pop(Fila_indice)
        for i in range(len(M)): M[i].pop(Columna_indice)
        return M