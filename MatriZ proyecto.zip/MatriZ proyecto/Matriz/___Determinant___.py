from ___Lower___ import Menor
def Determinant(Matriz=[],Fila_indice=0,Columna_indice=0):
    if len(Matriz)==len(Matriz[0])>Columna_indice:
       if len(Matriz)==1:
           return Matriz[0][0]
       else:
          return (Matriz[Fila_indice][Columna_indice]*Determinant(Menor(Matriz,Fila_indice,Columna_indice)))-Determinant(Matriz,Fila_indice,Columna_indice+1)
    elif Columna_indice>=len(Matriz[0]):
        return 0
    else:
        None

