def new_ubicacion(self):
    new=""
    for i in self :
        if i=="\\":
            new=new + "/"
        else:
            new=new+i
    return new
