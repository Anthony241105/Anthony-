def is_Square_Matriz(self):
    if len(self.matriz)==len(self.matriz[0]):
        return True
    else:
        return False