import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
x = np.linspace(0,10,100)
y = np.sin(x)
fig, ax =plt.subplots()
ax.plot(x, y)
ax.set_title("Funcion Seno")
ax.set_xlabel("Eje x")
ax.set_ylabel("Eje y")
st.pyplot(fig) 
#cd proyecto
#streamlit run prueba.py
