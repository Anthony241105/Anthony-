def Load_Data (Data: str=None,directory:str="C:/Users/ANAISY/proyecto"):
      Data=str(Data)
      with open(str(directory)+"/"+str(Data),"r",encoding="utf-8") as File_base:
             File_base=File_base.read()
             return File_base   
      