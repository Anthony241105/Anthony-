def Data_columna(self):
    matriz=[]
    fila=[]
    num=""
    for i in self:
        for e in range(len(i)):
            if i[e]==" ":
                num=int(num)
                fila.append(num)
                print(fila)
                num=""
            #elif e==len(i)-1:
               # num=float(int(num))
                #print(num)
                #fila.append(num)
            else:
                num=num+i[e]
        
        matriz.append(fila)
        fila=[]
    return matriz


        