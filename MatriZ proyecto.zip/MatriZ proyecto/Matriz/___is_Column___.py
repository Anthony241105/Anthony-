from ___Column___ import Column
def is_Column(self,Matriz):
        if self.matriz == Column(self,0,Matriz).matriz:
            return True
        else:
            return False